
var x = 6
var y = 7


alert ( x )




